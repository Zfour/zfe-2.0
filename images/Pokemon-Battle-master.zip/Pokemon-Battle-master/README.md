# Pokemon Battle!
The playable pokemons are **Pikachu**, **Charmander**, **Squirtle**, **Bulbasaur** and **Diglett**.

### Install

### Code
A fighter is a "blueprint" object with properties of `health` and `damagePerAttack`. Each pokemon is an instance of the blueprint object.

The function `emergeVictorious` contains parameters (player1, player2, firstAttacker), and return the victorious player of each match.

Each player takes turns attacking the opponent. The one with remaining hit points is the winner. 

The defeated player is one whose hit points is valued at **health <= 0**.

The `health` and `damagePerAttack` meters will be valued as **integer > 0**.

### Run

### Data
