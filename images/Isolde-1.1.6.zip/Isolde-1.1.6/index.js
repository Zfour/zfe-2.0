'use strict';

const isolde = require('./dist/isolde.min.js').default;

module.exports = isolde;
