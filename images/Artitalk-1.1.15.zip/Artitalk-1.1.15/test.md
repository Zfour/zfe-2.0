
|  博主   | 链接  | 框架  |主题  |
|  ----  | ----  |  ----  | ----  |
| Uncle_drew  | [https://cndrew.cn/shuoshuo/](https://cndrew.cn/shuoshuo/) | Hexo | [Sakura](https://github.com/honjun/hexo-theme-sakura)   |
| Jankin  | [https://chenzkun.top/shuoshuo/](https://chenzkun.top/shuoshuo/) | Hexo| [Butterfly](https://github.com/jerryc127/hexo-theme-butterfly)  |
| segment-tree  | [https://segment-tree.top/talk/](https://segment-tree.top/talk/) | Hexo |  [Volantis](https://volantis.js.org/)  |
| cungudafa  | [https://cungudafa.top/artitalk/](https://cungudafa.top/artitalk/) | Hexo |  [Butterfly](https://github.com/jerryc127/hexo-theme-butterfly)  |
| AngelNI  | [https://angelni.github.io/AngelNI.github.io/suisuinian/](https://angelni.github.io/AngelNI.github.io/suisuinian/)| Hexo | [Butterfly](https://github.com/jerryc127/hexo-theme-butterfly)  |
| GH670  | [https://wblog.tech/photos/Sshuo.html](https://wblog.tech/photos/Sshuo.html)| Hexo | [Yileas](https://github.com/GH670/yileas)  |
| zzx0826  | [https://www.zzx0826.top/shuoshuo/](https://www.zzx0826.top/shuoshuo/)| Hexo | [Butterfly](https://github.com/jerryc127/hexo-theme-butterfly)  |
